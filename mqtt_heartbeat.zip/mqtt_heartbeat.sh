#!/bin/sh
while true; do
sleep 30
if [ -e /mnt/mmc01/mosquitto_pub ]; then
 /mnt/mmc01/mosquitto_pub -h 192.168.68.119 -u mqtt --pw mqtt -m "heartbeat" -t home/doorbell/heartbeat
fi

